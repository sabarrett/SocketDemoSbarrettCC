var searchData=
[
  ['fade_57',['Fade',['../classraylib_1_1_color.html#a799b151b5ce92ccf5ca46f0c18ced395',1,'raylib::Color']]],
  ['fileexists_58',['FileExists',['../namespaceraylib.html#a9e94283307bcb33f4595dcd5236b65c4',1,'raylib']]],
  ['fliphorizontal_59',['FlipHorizontal',['../classraylib_1_1_image.html#a5d8f596d36077f4b8c24512a2df73e65',1,'raylib::Image']]],
  ['flipvertical_60',['FlipVertical',['../classraylib_1_1_image.html#a0f052c63b3cebcf99c0cad86c8e88da4',1,'raylib::Image']]],
  ['font_61',['Font',['../classraylib_1_1_font.html',1,'raylib::Font'],['../classraylib_1_1_font.html#a8a29c7a9f5aacc2073d407784774ff7d',1,'raylib::Font::Font(const std::string &amp;fileName)'],['../classraylib_1_1_font.html#a702dd1ec33bbb9c9ff6d0ccb7515dfd7',1,'raylib::Font::Font(const std::string &amp;fileName, int fontSize, int *fontChars, int charCount)'],['../classraylib_1_1_font.html#adfe1913d9f5aa7848fcb033fe7bc7ca2',1,'raylib::Font::Font(const ::Image &amp;image, ::Color key, int firstChar)'],['../classraylib_1_1_font.html#a4cfb9ae6c224437ad3d5c7c4f905b6ab',1,'raylib::Font::Font(const std::string &amp;fileType, const unsigned char *fileData, int dataSize, int fontSize, int *fontChars, int charsCount)']]],
  ['format_62',['Format',['../classraylib_1_1_image.html#a01fcff59e33e044bd779202ea3473c48',1,'raylib::Image::Format()'],['../classraylib_1_1_wave.html#a4e6d2e64e6cdd46133893c9edd70b508',1,'raylib::Wave::Format()']]],
  ['fromhsv_63',['FromHSV',['../classraylib_1_1_color.html#a6c3fd166762f68aede6c448cb26677ef',1,'raylib::Color']]],
  ['fromimage_64',['FromImage',['../classraylib_1_1_image.html#a61259f828d00df0dbe8430276652d7aa',1,'raylib::Image']]]
];
